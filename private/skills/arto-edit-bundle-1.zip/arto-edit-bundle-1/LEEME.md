# ARTO Edit Bundle #1

9 skills para que Claude edite tus videos verticales. Hecho por ARTO Studio AI · creative.artostudio.ai

*English below.*

## Qué trae

| Skill | Qué hace |
|---|---|
| `arto-edit-director` | Te propone un storyboard escena por escena, no edita hasta que lo apruebas y luego usa los demás en orden |
| `arto-edit-cortes` | Quita silencios, muletillas y tomas repetidas |
| `arto-edit-subtitulos` | Subtítulos palabra por palabra, blancos con sombra y sin caja |
| `arto-edit-letras-detras` | Pone un titular detrás de tu cabeza |
| `arto-edit-recuadros` | Tarjetas flotantes con capturas, videos, el prompt en pantalla o íconos |
| `arto-edit-titulares` | Titulares estilo portada de revista |
| `arto-edit-color` | Looks de color: cálido, oscuro, limpio y blanco y negro |
| `arto-edit-zooms` | Zooms suaves en las frases importantes |
| `arto-edit-sonido` | Música, whooshes, efectos y volumen final a −14 LUFS |

Cada uno sirve solo («ponle subtítulos a este video») o juntos con el director («edita mi video completo»).

## Qué necesitas

- **Claude Code** en tu computadora. Lo único de pago es tu plan de Claude.
- **ffmpeg** instalado. En Mac, `brew install ffmpeg`; en Windows, `winget install ffmpeg`; en Linux, `sudo apt install ffmpeg`.
- **Python 3.9 o más** (en Windows se llama con `py -3`). Cada skill trae `scripts/check_setup.py`, que revisa e instala lo demás gratis: Whisper, Pillow, numpy y rembg.
- **La primera vez se bajan dos modelos gratis:** el de Whisper (de 0.8 a 1.5 GB, a `~/.cache`) y el de recorte de rembg (unos 170 MB, a `~/.u2net`). Después ya no.
- Un video vertical tuyo hablando a cámara.

## Cómo se instala

**En Claude Code**, el que edita:

1. Descomprime cada `.skill` (es un zip) dentro de `~/.claude/skills/`. Te queda `~/.claude/skills/arto-edit-director/SKILL.md` y así con los 9.
2. Abre una sesión nueva de Claude Code en la carpeta de tu video.
3. Dile, por ejemplo: «Edita mi video completo con el director» o «Ponle subtítulos a video.mp4».

**En claude.ai:** sube cada `.skill` en la sección de Skills de tu configuración. Ahí sirven para planear (storyboard, textos, prompts), pero la edición necesita Claude Code, porque corre ffmpeg en tu computadora.

**En ChatGPT** sirven para planear, no editan.

## Lo que conviene saber

- Nunca se toca tu original: cada paso guarda un archivo nuevo al lado.
- Antes de un proceso largo, Claude te dice cuánto va a tardar.
- Las letras detrás de la cabeza salen mejor con un fondo que contraste contigo y con espacio arriba de tu cabeza.
- Las fuentes que vienen dentro (Manrope, Inter Tight, Cormorant Garamond y Bebas Neue) son libres, con licencia OFL. Su licencia va al lado de cada una.

---

# ARTO Edit Bundle #1 (English)

9 skills so Claude can edit your vertical videos. Made by ARTO Studio AI · creative.artostudio.ai

## What's inside

| Skill | What it does |
|---|---|
| `arto-edit-director` | Proposes a scene-by-scene storyboard, doesn't edit until you approve it, then uses the others in order |
| `arto-edit-cortes` | Cuts silences, filler words and repeated takes |
| `arto-edit-subtitulos` | Word-by-word captions, white with a shadow and no box |
| `arto-edit-letras-detras` | Puts a headline behind your head |
| `arto-edit-recuadros` | Pop-up cards with screenshots, clips, the prompt on screen or icons |
| `arto-edit-titulares` | Magazine-cover headlines |
| `arto-edit-color` | Color looks: warm, moody, clean and black and white |
| `arto-edit-zooms` | Smooth zooms on the key lines |
| `arto-edit-sonido` | Music, whooshes, sound effects and final loudness at −14 LUFS |

Use any of them alone ("add captions to this video") or all together with the director ("edit my whole video").

## What you need

- **Claude Code** on your computer. Your Claude plan is the only paid part.
- **ffmpeg** installed. On a Mac, `brew install ffmpeg`; on Windows, `winget install ffmpeg`; on Linux, `sudo apt install ffmpeg`.
- **Python 3.9 or newer** (on Windows, run it as `py -3`). Each skill ships `scripts/check_setup.py`, which checks for and installs the rest for free: Whisper, Pillow, numpy and rembg.
- **The first run downloads two free models:** Whisper's (0.8 to 1.5 GB, into `~/.cache`) and rembg's cut-out model (about 170 MB, into `~/.u2net`). Only once.
- A vertical video of you talking to the camera.

## How to install

**In Claude Code** (where the editing happens):

1. Unzip each `.skill` (it's a zip) into `~/.claude/skills/`. You end up with `~/.claude/skills/arto-edit-director/SKILL.md` and so on for all 9.
2. Open a new Claude Code session in your video's folder.
3. Ask, for example: "Edit my whole video with the director" or "Add captions to video.mp4".

**In claude.ai:** upload each `.skill` in the Skills section of your settings. There they help you plan (storyboard, copy, prompts), but editing needs Claude Code, because it runs ffmpeg on your computer.

**In ChatGPT** they help you plan; they don't edit.

## Good to know

- Your original is never touched: each step saves a new file next to it.
- Before a long job, Claude tells you how long it will take.
- Text behind your head works best with a background that contrasts with you and some room above your head.
- The bundled fonts (Manrope, Inter Tight, Cormorant Garamond and Bebas Neue) are free under the OFL license, which sits next to each one.
