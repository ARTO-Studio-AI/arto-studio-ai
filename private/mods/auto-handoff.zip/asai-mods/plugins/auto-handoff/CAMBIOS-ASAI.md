# auto-handoff-asai · cambios de ARTO Studio AI sobre auto-handoff

Base: `auto-handoff` 0.8.6 de Alex Hillman, repositorio `alexknowshtml/claude-auto-handoff`, commit `8d762ce726c962268e2dbe24c1c60f0889a2fcde`, licencia MIT (texto completo en `LICENSE`). Versión ajustada: `0.8.6-asai.2`. Cambios de ARTO Studio AI (ASAI), octubre de 2026. Cada cambio en el código está marcado con `ASAI:`. El `README.md` es el del autor y describe el mod original, donde el parte siempre lo escribe Haiku; este archivo dice qué cambia.

## Qué cambia
1. **Tú eliges quién escribe el parte: Sonnet o Haiku.** Es la opción `briefModel` de la configuración del mod. Si no se fija, o si tiene otro valor, es `sonnet`. En el original, el parte siempre lo escribe Haiku. `hooks/config.ts`, `hooks/register.tsx` y `.claude-plugin/plugin.json`.
2. **Con Sonnet, el parte ve más de la conversación:** los últimos 400 mensajes, hasta 4.000 caracteres por mensaje, 600 por entrada de herramienta y un tope total de 600.000 caracteres. La respuesta puede llegar a 8.000 tokens y la espera a 180 s. **Con Haiku se quedan los valores del original:** 120 mensajes, 2.000, 300 y 150.000 caracteres, respuesta de hasta 4.000 tokens y 60 s de espera. `hooks/brief.ts`.
3. **Si la llamada al modelo falla con una excepción** (por ejemplo, porque tu organización no permite ese modelo), el mod usa el parte solo con hechos y termina el relevo. En el original, esa excepción dejaba el relevo atascado y rechazaba todas las herramientas.
4. El parte, el registro y la descripción del plugin dicen qué modelo escribió el parte.

No cambia nada más: el umbral, el visor, los seguros contra bucles y el resto del código son los del autor.

## Por qué recomendamos Sonnet
Lo probamos a ciegas el 26 de octubre de 2026 con 5 sesiones reales de unos 400.000 tokens, de cinco proyectos distintos. Para cada sesión escribimos dos partes, uno con cada modelo y sus límites de lectura, los barajamos y un revisor independiente los calificó contra el registro completo sin saber cuál era cuál. **El de Sonnet ganó en 4 de las 5** y tuvo la mitad de errores (11 contra 21). El de Haiku era más largo y cubría más temas, pero varias veces daba por pendientes cosas que ya estaban resueltas, y eso manda a la sesión nueva a repetir trabajo. Fueron llamadas sueltas, sin el tope de 4.000 tokens de respuesta ni el minuto de espera que la opción Haiku sí aplica dentro del mod; en una de las 5 sesiones, Haiku pasó del minuto.

## Lo que hay que saber
- **Sonnet cuesta más por relevo.** En la prueba, unos USD 0,22 por relevo con Sonnet (de 0,17 a 0,30) contra unos USD 0,012 con Haiku: unas 19 veces más. Sale de tu plan, igual que el resto de la conversación.
- **Mientras se escribe el parte, Claude no puede usar herramientas.** Sonnet: de 12 a 16 s en vivo dentro del mod y de 19 a 31 s en la prueba a ciegas. Haiku: de 43 a 64 s en la prueba a ciegas (no lo corrimos en vivo). El tope es de 180 s con Sonnet y 60 s con Haiku.
- **Con sesiones largas, la opción Haiku puede pasar su minuto**, y entonces el relevo sale con el parte solo de hechos.
- **Un umbral muy bajo encadena relevos**, igual que en el original. Con los valores recomendados no pasa.

## Cómo se comprobó
- `claude plugin test .` con Claude Code 2.1.308: 87 de 87 pruebas (81 del autor y 6 de ASAI: el modelo por defecto y la opción Haiku, cada uno con su tope de respuesta y de espera; un valor desconocido que cae a Sonnet; una excepción del modelo que cae al parte de hechos, y los límites de lectura de cada modelo).
- `claude plugin validate`: Validation passed.
- Una auditoría independiente del cambio, antes de publicarlo.
- La versión con Sonnet la usamos en nuestro propio equipo desde el 26 de octubre de 2026.
