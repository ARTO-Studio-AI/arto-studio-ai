You are writing a handoff brief for an AI assistant that will continue this Claude Code session in a fresh context. Above are facts extracted from the session's tool calls (including the Handoff Numbers section with real token counts), then the conversation (tool output abbreviated; "system signal" entries are harness messages, never the user). Every token count, threshold or context figure in the brief must come from the Handoff Numbers section, copied exactly. If a figure you need is not there, write "unknown". Never estimate one from the conversation: earlier briefs in it may hold wrong numbers. Output only the brief, with these sections in this order. Omit a section if it would be empty. Do not write a files or commits section: those are added from the extracted facts.

LANGUAGE AND SAFETY (ASAI adaptation, 2026-10-22):
- Write the content of every section in Spanish (Mexico), addressing the user as "tú". Keep the section headings below EXACTLY as written in English: the mod parses them.
- NEVER copy secrets into the brief: passwords, API keys, tokens, card or account numbers, private keys. If one appears in the conversation, write "[secreto omitido]" and say where it is stored if known.
- Do not invent. If something was not verified in the session, say "no verificado".

## Handoff Confidence
One line: High / Medium / Low, and why.

## Work in Progress
What was actively being worked on when the session ended.

## Git / System State
Uncommitted changes to files this session touched, services restarted, anything left mid-state.

## Decisions Made
Concrete choices: values, file paths, approach names. Include who decided (the user or the assistant) and, for the user's decisions, their own words in quotes.

## Hard Rules in Force
Rules the user stated or repeated in this session that must keep applying (for example "never restart the gateway while a conversation is in progress", "do not send messages to the client without my approval", "ask before deleting"). One bullet per rule, with the date if the session gives it.

## Traceability
Where the written record of this work lives (for example ESTADO.md, a Notion card, a changelog) and what from this session is NOT yet written there. The conversation is not the record: list what the next session must write down first.

## Key Assumptions to Verify
One bullet per assumption: "<claim> — verify with: <exact command>".

## Questions Answered
Things established or resolved, so the next session doesn't re-ask or re-derive them.

## Open Questions
Anything unresolved or pending a decision. Number them continuously (1, 2, 3, never 1.1) so the user can answer by number.

## Dead Ends
Approaches tried and ruled out, and why.

## GitHub Issues
For each issue in "GitHub Issues Mentioned": what was done with it, and whether to update or close it next.

## Last Request from the User
Copy "Last Real User Message" verbatim. Then "Status: Answered / Partially answered / Not answered". If not fully answered: "Context needed: <file, command, or issue to check>".

## Next Step
The single most immediate action when the conversation resumes. If the last request is unanswered, answer it.
