// Copyright 2026 Anthropic PBC
// SPDX-License-Identifier: Apache-2.0
//
// Blast Radius: holds a risky Bash command and shows what it would change.
//
// tool.call (Bash): if the command is risky, work out its blast radius, open a
// pane with Proceed and Cancel, and hold the call until one is pressed.
// ui.render (Pane): draws the report. If the surface won't place the pane (a
// narrow terminal), the same report is drawn in the AbovePrompt band instead.
//
// Holding: a hook has 10 s of its own time, but time spent inside a `$` call is
// free. So the hold loop waits on a short `$.process.run(["sleep", ...])` until
// a button's onPress sets the decision.
//
// The host reads `on(...)` and `$.noun.method(...)` from source, so they are
// spelled literally, and helpers that take `$` are top-level functions.
//
// Ajuste ASAI (ARTO Studio AI, 25 oct 2026), sobre el commit 569c528 de
// anthropics/claude-code-playground. Cambios, todos marcados "ASAI:":
// 1. Parte la línea de comandos respetando comillas (en && || ; | |& & y saltos
//    de línea), y revisa lo que va dentro de bash/sh/zsh -c, eval, xargs,
//    timeout, doas, env, time, npx, bunx, pnpm/yarn/bun dlx|exec|x, find -exec,
//    $(...) y comillas invertidas. Lo interno inocuo no limpia el tramo: se
//    revisa también el envoltorio (find -exec echo {} \; -delete).
// 2. Suma comandos de nuestro stack: supabase db reset/push (no con --dry-run),
//    functions/projects/branches delete, storage rm y migration repair; SQL
//    destructivo hacia psql, mysql, sqlite3 o pgcli (con -c, y también SQL que
//    llega por -f, < , heredoc o pipe, aun tras sudo, VAR= o docker exec, que se
//    retiene sin leerse, así que también atrapa lecturas que llegan por ahí);
//    vercel env/domains/dns/projects/alias rm
//    y vercel rm; drizzle-kit push/drop; prisma db push y migrate reset;
//    scripts db:push/db:reset/db:drop de npm, pnpm, yarn y bun; git branch -D,
//    git stash drop/clear, git push --delete o :rama, git worktree remove
//    --force; gh repo/release delete, gh api con DELETE y gh pr close
//    --delete-branch; find -delete (medido con un simulacro sin -delete).
// 3. Si el turno lo disparó una tarea programada, rutina o /loop, o la sesión
//    no tiene pantalla, rechaza al instante en vez de esperar 10 minutos. Con
//    tarea programada rechaza aunque haya alguien en la pantalla: una tarea no
//    debe quedarse esperando a una persona.
// 4. BLAST_RADIUS_ASAI=off en el entorno del proceso lo apaga.
// Límites que siguen: solo vigila la herramienta Bash; no lee scripts ni
// archivos .sql; no ve intérpretes (python3 -c, node -e) que borran por dentro.
// classify se exporta para las pruebas; el mod carga igual (comprobado en vivo).

const PANE_ID = "blast-radius";
const POLL_SECONDS = "0.25";
const HOLD_LIMIT_MS = 10 * 60 * 1000;
const LIST_MAX = 10;

// The call being held, or null. One at a time: Bash calls in a turn run in order.
let held = null;

// ASAI: true while the current turn was started by a scheduled task, routine or /loop.
let unattended = false;

export function register(on) {
  on("prompt.submit", ($, e, next) => {
    // Only a prompt that starts a turn sets it. A notification or a peer's
    // message delivered into the running turn (turnId set) leaves it as it is.
    if (e.turnId === undefined) {
      unattended = e.origin?.kind === "scheduled-trigger";
    }
    return next(e);
  });

  on("tool.call", { tool: "Bash" }, async ($, e, next) => {
    const risk = classify(String(e.command ?? ""));
    if (risk === null) {
      return next(e);
    }
    // ASAI: an off switch, and an answer right away when nobody can press a button.
    if ((await $.env.get("BLAST_RADIUS_ASAI")) === "off") {
      return next(e);
    }
    const surfaces = await $.session.surfaces();
    if (unattended || surfaces.length === 0) {
      const why = unattended ? "the turn was started by a scheduled task" : "no screen is attached to this session";
      return {
        deny: `Blast Radius held this command and did not run it: ${why}, so nobody can confirm it. It is: ${risk.label}. Do not retry it; tell the user it needs their confirmation.`,
      };
    }
    // One hold at a time. If another risky call is already held (a subagent's,
    // say), wait until it is answered. `held` is claimed with no await between
    // the check and the claim, so two waiting calls can't both get through.
    while (held !== null) {
      if (next.signal.aborted) {
        return { deny: "Blast Radius held this command and did not run it: the turn was interrupted. Do not retry it unless the user asks you to." };
      }
      await $.process.run(["sleep", POLL_SECONDS], { timeoutMs: 5000 });
    }
    const mine = { command: String(e.command), risk, report: null, decision: null, where: "pane" };
    held = mine;

    let opened = { isPlaced: false };
    let decision;
    let summary = risk.label;
    try {
      // Measure where the command will run: the session folder, moved by any
      // `cd dir &&` or `git -C dir` earlier in the same command line.
      const sessionCwd = await $.session.cwd();
      const cwd = risk.dir ? await resolveDir($, sessionCwd, risk.dir) : sessionCwd;
      mine.report = cwd === null
        ? { summary: `${risk.label} in ${risk.dir}`, lines: [], note: `Couldn't find the folder ${risk.dir}, so I couldn't measure what this would change.` }
        : await measure($, risk, cwd);
      summary = mine.report.summary;

      opened = await $.ui.open({ id: PANE_ID, title: "Blast Radius", focus: true, rows: paneRows(mine.report) });
      if (!opened.isPlaced) {
        mine.where = "band";
      }
      $.ui.invalidate("ui.render");

      const startedAt = await $.clock.now();
      while (mine.decision === null) {
        if (next.signal.aborted) {
          mine.decision = "interrupted";
          break;
        }
        if ((await $.clock.now()) - startedAt > HOLD_LIMIT_MS) {
          mine.decision = "timeout";
          break;
        }
        await $.process.run(["sleep", POLL_SECONDS], { timeoutMs: 5000 });
      }
    } catch {
      mine.decision = "error"; // anything unexpected refuses the command
    } finally {
      decision = mine.decision;
      // Close this call's pane before releasing the hold, so the next call's
      // pane can't be the one that gets closed.
      try {
        if (opened.isPlaced) {
          await $.ui.close({ id: PANE_ID });
        }
      } catch {
        // the pane is already gone
      }
      if (held === mine) {
        held = null;
      }
      $.ui.invalidate("ui.render");
    }

    if (decision === "proceed") {
      $.ui.toast("Blast Radius: running it");
      return next(e);
    }
    const why = {
      cancel: "the user pressed Cancel",
      timeout: "no answer within 10 minutes",
      interrupted: "the turn was interrupted",
      error: "Blast Radius hit an error while holding it",
    }[decision] ?? "no answer was recorded";
    return {
      deny: `Blast Radius held this command and did not run it: ${why}. It would have: ${summary}. Do not retry it unless the user asks you to.`,
    };
  });

  on("ui.render", { component: "Pane" }, ($, e, next) => {
    if (e.requestId !== PANE_ID || held === null || held.report === null) {
      return next(e);
    }
    return draw($.ui.resolve(e), held);
  });

  on("ui.render", { component: "AbovePrompt" }, ($, e, next) => {
    if (held === null || held.report === null || held.where !== "band") {
      return next(e);
    }
    return draw($.ui.resolve(e), held);
  });
}

// ---- What counts as risky -------------------------------------------------

// sudo options that take a value, so the value isn't read as the command.
const SUDO_VALUE_OPTIONS = new Set(["-u", "-g", "-C", "-D", "-h", "-p", "-r", "-t", "-T", "-U"]);
// Commands that only read, so a bare word "migrate" in them isn't a migration.
const READ_ONLY = new Set(["ls", "cat", "echo", "printf", "grep", "rg", "find", "less", "head", "tail", "cd", "git"]);

/** A folder a later `cd arg` moves to, given the folder so far (null = the session folder). */
function joinDir(dir, arg) {
  if (arg === undefined || arg === "~" || arg.startsWith("/") || arg.startsWith("~/")) {
    return arg ?? "~";
  }
  return dir ? `${dir}/${arg}` : arg;
}

// ASAI: how deep wrappers are opened (bash -c "eval 'sh -c ...'"), so a crafted
// line can't loop forever. Past it, the line is held as unreadable.
const MAX_DEPTH = 4;

/**
 * ASAI: splits a command line on && || ; | |& & and newlines that are outside
 * quotes. Each segment says whether a pipe feeds its stdin.
 */
function splitSegments(command) {
  const out = [];
  let cur = "";
  let quote = null;
  let piped = false; // whether the segment being read gets a pipe's output
  const cut = (nextPiped) => {
    out.push({ text: cur, piped });
    cur = "";
    piped = nextPiped;
  };
  for (let i = 0; i < command.length; i += 1) {
    const c = command[i];
    if (quote !== null) {
      cur += c;
      if (c === "\\" && quote === '"' && i + 1 < command.length) {
        i += 1;
        cur += command[i];
      } else if (c === quote) {
        quote = null;
      }
      continue;
    }
    if (c === "'" || c === '"') {
      quote = c;
      cur += c;
      continue;
    }
    if (c === "\\" && i + 1 < command.length) {
      cur += c + command[i + 1];
      i += 1;
      continue;
    }
    const two = command.slice(i, i + 2);
    if (two === "&&" || two === "||" || two === "|&") {
      cut(two === "|&");
      i += 1;
      continue;
    }
    // A lone & runs what comes before it in the background; &> , >& and 2>&1 are redirects.
    if (c === "&" && command[i + 1] !== ">" && command[i - 1] !== ">" && command[i - 1] !== "<") {
      cut(false);
      continue;
    }
    if (c === ";" || c === "|" || c === "\n") {
      cut(c === "|");
      continue;
    }
    cur += c;
  }
  cut(false);
  return out;
}

/** ASAI: the command lines inside $(...) and backticks, outside single quotes. */
function substitutions(command) {
  const found = [];
  let quote = null;
  for (let i = 0; i < command.length; i += 1) {
    const c = command[i];
    if (quote === "'") {
      if (c === "'") quote = null;
      continue;
    }
    if (c === "'" && quote === null) {
      quote = "'";
      continue;
    }
    if (c === '"') {
      quote = quote === '"' ? null : '"';
      continue;
    }
    if (c === "$" && command[i + 1] === "(" && command[i + 2] !== "(") {
      let depth = 1;
      let j = i + 2;
      while (j < command.length && depth > 0) {
        if (command[j] === "(") depth += 1;
        else if (command[j] === ")") depth -= 1;
        j += 1;
      }
      found.push(command.slice(i + 2, j - 1));
      i = j - 1;
    } else if (c === "`") {
      const end = command.indexOf("`", i + 1);
      if (end === -1) break;
      found.push(command.slice(i + 1, end));
      i = end;
    }
  }
  return found;
}

/** The first risky segment of a shell command, or null. */
export function classify(command, depth = 0) {
  if (depth > MAX_DEPTH) {
    return { kind: "stack", label: "nested shell", what: "a command nested too deep to read", dir: null };
  }
  // ASAI: what runs inside $(...) or backticks runs too.
  for (const inner of substitutions(command)) {
    const risk = classify(inner, depth + 1);
    if (risk !== null) {
      return { ...risk, label: `${risk.label} (inside $(...))` };
    }
  }
  let dir = null; // where a `cd` earlier on the line moved to; null means the session folder
  const scopes = []; // dir to restore when a ( subshell ) closes
  const pushed = []; // pushd stack, for popd
  for (const { text: raw, piped } of splitSegments(command)) {
    // ASAI: SQL piped into a database client isn't on the client's own line.
    // Read after sudo, VAR= and wrappers like docker exec: any SQL client word counts.
    // A ( or ) glued to a word isn't part of it: (echo x | psql).
    const pipedWords = piped ? tokenize(raw.trim().replace(/^[({]+\s*/, "").replace(/\s*[)}]+$/, "")).filter((w) => !/^[A-Za-z_][A-Za-z0-9_]*=/.test(w)) : [];
    if (pipedWords.length > 0 && !TEXT_TOOLS.has(pipedWords[0].split("/").pop()) && pipedWords.some((w) => SQL_CLIENTS.has(w.split("/").pop()))) {
      const client = pipedWords.find((w) => SQL_CLIENTS.has(w.split("/").pop())).split("/").pop();
      return { kind: "stack", label: `SQL piped into ${client}`, what: "run SQL that comes through a pipe, which Blast Radius can't read", dir };
    }
    const opens = (raw.match(/^\s*\(+/)?.[0].trim().length) ?? 0;
    // Trailing redirects and & don't hide a closing ) : `(cd sub && make) > log`.
    const tail = raw.replace(/(?:\s*(?:\d*>>?|&>>?|<)\s*\S+|\s*&)+\s*$/, "");
    const closes = (tail.match(/\)+\s*$/)?.[0].trim().length) ?? 0;
    for (let k = 0; k < opens; k += 1) {
      scopes.push(dir);
    }
    const risk = classifySegment(raw, dir, pushed, depth);
    if (risk !== null && risk.cd === undefined) {
      return risk;
    }
    if (risk !== null) {
      dir = risk.cd; // a cd, pushd or popd moved the folder
    }
    for (let k = 0; k < closes && scopes.length > 0; k += 1) {
      dir = scopes.pop(); // a cd inside ( ... ) doesn't outlive it
    }
  }
  return null;
}

// Words that can come before the real command without changing what it does.
const PREFIXES = new Set(["command", "exec", "env", "nohup", "time", "then", "do", "else", "!"]);

/** One segment: a risk, { cd } for a folder change, or null. */
function classifySegment(segment, dir, pushed, depth = 0) {
  {
    const words = tokenize(segment.trim().replace(/^[({]+\s*/, "").replace(/\s*[)}]+$/, ""));
    while (words.length > 0 && /^[A-Za-z_][A-Za-z0-9_]*=/.test(words[0])) {
      words.shift(); // leading VAR=value
    }
    if (words[0] === "sudo") {
      words.shift();
      while (words.length > 0 && words[0].startsWith("-")) {
        const option = words.shift();
        if (SUDO_VALUE_OPTIONS.has(option)) {
          words.shift();
        }
      }
    }
    while (words.length > 0 && (PREFIXES.has(words[0]) || /^[A-Za-z_][A-Za-z0-9_]*=/.test(words[0]))) {
      words.shift();
      // ASAI: options of a prefix (`env -i`, `time -p`) aren't the command either.
      while (words.length > 0 && words[0].startsWith("-")) {
        words.shift();
      }
    }
    if (words[0] === "nice") {
      words.shift();
      if (words[0] === "-n") {
        words.splice(0, 2);
      } else if (/^-\d+$/.test(words[0] ?? "")) {
        words.shift();
      }
    }
    const [first, ...args] = words;
    if (first === undefined) {
      return null;
    }
    const cmd = first.replace(/^\\/, ""); // \rm skips aliases; it's still rm
    // ASAI: a wrapper runs another command line; read that one instead.
    const inner = unwrap(cmd, args);
    const innerRisk = inner === null ? null : classify(inner, depth + 1);
    // A harmless inner command doesn't clear the wrapper: find -exec echo {} \; -delete.
    if (innerRisk !== null) {
      const risk = innerRisk;
      const base = cmd.split("/").pop();
      // The paths of find -exec and xargs come at run time, so the inner command can't be measured.
      // ASAI: inside docker exec or ssh it runs elsewhere, so measuring it here would mislead.
      if (base === "docker" || base === "docker-compose" || base === "ssh") {
        return { kind: "stack", label: `${risk.label.replace(/ \(inside [^)]*\)$/, "")} (inside ${base})`, what: `run ${risk.label} ${base === "ssh" ? "on another machine" : "inside a container"}, which Blast Radius can't measure from here`, dir };
      }
      if (base === "find" || base === "xargs") {
        return { kind: "stack", label: `${base} ${risk.label}`, what: `run ${risk.label} on every path ${base === "find" ? "find matches" : "piped into xargs"}`, dir };
      }
      return { ...risk, label: `${risk.label} (inside ${base})`, dir: risk.dir === null || risk.dir === undefined ? dir : joinDir(dir, risk.dir) };
    }
    const stack = classifyStack(cmd, args, words);
    if (stack !== null) {
      return { ...stack, dir };
    }
    if (cmd === "cd") {
      return { cd: args[0] === "-" ? "-" : joinDir(dir, args[0]) };
    }
    if (cmd === "pushd") {
      pushed.push(dir);
      return { cd: joinDir(dir, args[0]) };
    }
    if (cmd === "popd") {
      return { cd: pushed.length > 0 ? pushed.pop() : "-" };
    }
    if (cmd === "rm" || cmd.endsWith("/rm")) {
      const flags = args.filter((a) => a.startsWith("-"));
      const recursive = flags.some((f) => f === "--recursive" || (/^-[^-]/.test(f) && /[rR]/.test(f)));
      const force = flags.some((f) => f === "--force" || (/^-[^-]/.test(f) && f.includes("f")));
      if (recursive || force) {
        const targets = args.filter((a) => !a.startsWith("-") || a === "-");
        return { kind: "rm", label: `rm ${flags.join(" ")}`.trim(), targets, dir };
      }
    }
    if (cmd === "git") {
      // Git's own options come before the subcommand; -C moves where it runs.
      let gitDir = dir;
      let i = 0;
      while (i < args.length && args[i].startsWith("-")) {
        if (args[i] === "-C" && i + 1 < args.length) {
          gitDir = joinDir(gitDir, args[i + 1]);
          i += 2;
        } else if (args[i] === "-c" && i + 1 < args.length) {
          i += 2;
        } else {
          i += 1;
        }
      }
      const sub = args[i];
      const rest = args.slice(i + 1);
      if (sub === "reset" && rest.includes("--hard")) {
        return { kind: "git-reset", label: "git reset --hard", args: rest, dir: gitDir };
      }
      if (sub === "clean") {
        return { kind: "git-clean", label: "git clean", args: rest, dir: gitDir };
      }
      if (sub === "push" && rest.some((a) => a === "--force" || a === "-f" || a.startsWith("--force-with-lease") || /^\+/.test(a))) {
        return { kind: "git-push-force", label: "git push --force", args: rest, dir: gitDir };
      }
      const stagedOnly = sub === "restore" && rest.includes("--staged") && !rest.includes("--worktree") && !rest.includes("-W");
      if ((sub === "checkout" || sub === "restore") && rest.includes(".") && !stagedOnly) {
        return { kind: "git-checkout", label: `git ${sub} -- .`, args: rest, dir: gitDir };
      }
    }
    const joined = words.join(" ");
    if (/\balembic\s+upgrade\b/.test(joined)) {
      return { kind: "migrate", tool: "alembic", label: "alembic upgrade", dir };
    }
    if (/\bdb:migrate(?!:status\b)/.test(joined)) {
      return { kind: "migrate", tool: "rails", label: "db:migrate", dir };
    }
    if (/\bprisma\s+migrate\b/.test(joined)) {
      return { kind: "migrate", tool: "prisma", label: "prisma migrate", dir };
    }
    if (/\bmanage\.py\s+migrate\b/.test(joined)) {
      return { kind: "migrate", tool: "django", label: "manage.py migrate", dir };
    }
    if (!READ_ONLY.has(cmd) && args.includes("migrate")) {
      return { kind: "migrate", tool: "unknown", label: "migrate", dir };
    }
  }
  return null;
}

// ---- ASAI: wrappers and our stack --------------------------------------------

const SHELLS = new Set(["bash", "sh", "zsh", "dash", "ksh"]);
// Options that take a value, per wrapper, so the value isn't read as the command.
const XARGS_VALUE_OPTIONS = new Set(["-I", "-i", "-n", "-P", "-L", "-l", "-d", "-E", "-e", "-s", "-a"]);
const TIMEOUT_VALUE_OPTIONS = new Set(["-s", "--signal", "-k", "--kill-after"]);
const DOAS_VALUE_OPTIONS = new Set(["-u", "-C"]);
const NPX_VALUE_OPTIONS = new Set(["-p", "--package", "-c", "--call"]);
// ASAI: docker exec, docker compose exec and ssh run a command elsewhere.
const DOCKER_EXEC_VALUE_OPTIONS = new Set(["-e", "--env", "--env-file", "-u", "--user", "-w", "--workdir", "--index", "--detach-keys"]);
const DOCKER_GLOBAL_VALUE_OPTIONS = new Set(["-f", "--file", "-p", "--project-name", "--project-directory", "--env-file", "--profile", "--context", "-c", "-H", "--host", "-l", "--log-level", "--config"]);
const SSH_VALUE_OPTIONS = new Set(["-p", "-i", "-l", "-o", "-F", "-J", "-L", "-R", "-D", "-b", "-c", "-E", "-m", "-O", "-Q", "-S", "-W", "-w", "-B", "-I"]);
const SUPABASE_VALUE_OPTIONS = new Set(["--workdir", "--profile", "--dns-resolver", "-o", "--output", "--network-id"]);
const VERCEL_VALUE_OPTIONS = new Set(["--token", "-t", "--scope", "-S", "--team", "-T", "--cwd", "--local-config", "-A", "--global-config", "-Q"]);
// Bins of our stack that pnpm, yarn and bun run without dlx.
const PACKAGE_BINS = new Set(["drizzle-kit", "prisma", "supabase", "vercel"]);
// Package scripts that by their name change a database: db:push, db:reset, db-drop...
const DB_SCRIPT = /\bdb[:\-_.]?(push|reset|drop|wipe|nuke)\b/i;

/** Skips leading options (and the values of those that take one); returns the index of the first other word. */
function skipOptions(args, valueOptions) {
  let i = 0;
  while (i < args.length && args[i].startsWith("-") && args[i] !== "-") {
    if (args[i] === "--") {
      return i + 1;
    }
    i += valueOptions.has(args[i]) ? 2 : 1;
  }
  return i;
}

/** ASAI: words back into a line with their quotes, so bash -c 'rm -rf x' stays one argument. eval and ssh re-read their words, so they don't use this. */
function rejoin(words) {
  return words.map((w) => (!/[\s;&|<>()$`]/.test(w) ? w : !w.includes("'") ? `'${w}'` : !w.includes('"') ? `"${w}"` : w)).join(" ");
}

/** The command line a wrapper runs, or null when `cmd` isn't a wrapper. */
function unwrap(cmd, args) {
  const base = cmd.split("/").pop();
  if (SHELLS.has(base)) {
    const at = args.findIndex((a) => /^-[A-Za-z]*c[A-Za-z]*$/.test(a));
    return at !== -1 && at + 1 < args.length ? args[at + 1] : null;
  }
  if (base === "eval") {
    return args.length > 0 ? args.join(" ") : null;
  }
  if (base === "xargs") {
    const rest = args.slice(skipOptions(args, XARGS_VALUE_OPTIONS));
    return rest.length > 0 ? rejoin(rest) : null;
  }
  if (base === "timeout" || base === "gtimeout") {
    const rest = args.slice(skipOptions(args, TIMEOUT_VALUE_OPTIONS) + 1); // + 1 skips the duration
    return rest.length > 0 ? rejoin(rest) : null;
  }
  if (base === "doas") {
    const rest = args.slice(skipOptions(args, DOAS_VALUE_OPTIONS));
    return rest.length > 0 ? rejoin(rest) : null;
  }
  if (base === "npx" || base === "bunx") {
    const rest = args.slice(skipOptions(args, NPX_VALUE_OPTIONS));
    return rest.length > 0 ? rejoin(rest) : null;
  }
  if ((base === "pnpm" || base === "yarn" || base === "bun") && (args[0] === "dlx" || args[0] === "exec" || args[0] === "x")) {
    const rest = args.slice(1);
    return rest.length > 0 ? rejoin(rest) : null;
  }
  // pnpm, yarn and bun also run a package's bin straight: pnpm drizzle-kit push.
  if ((base === "pnpm" || base === "yarn" || base === "bun") && PACKAGE_BINS.has(args[0])) {
    return rejoin(args);
  }
  // ASAI: docker exec [options] container cmd; docker compose exec [options] service cmd; ssh [options] host cmd.
  if (base === "docker" || base === "docker-compose") {
    // Global options can come first: docker --context mini exec, docker compose -f x.yml exec.
    let words = args.slice(skipOptions(args, DOCKER_GLOBAL_VALUE_OPTIONS));
    if (base === "docker" && words[0] === "compose") {
      words = words.slice(1);
      words = words.slice(skipOptions(words, DOCKER_GLOBAL_VALUE_OPTIONS));
    }
    if (words[0] === "exec") {
      const after = words.slice(1);
      const rest = after.slice(skipOptions(after, DOCKER_EXEC_VALUE_OPTIONS) + 1); // + 1 skips the container
      return rest.length > 0 ? rejoin(rest) : null;
    }
  }
  if (base === "ssh") {
    const rest = args.slice(skipOptions(args, SSH_VALUE_OPTIONS) + 1); // + 1 skips the host
    return rest.length > 0 ? rest.join(" ") : null; // the remote shell re-reads it, like eval
  }
  if (base === "find") {
    // find ... -exec cmd {} ; runs cmd once per file.
    const at = args.findIndex((a) => a === "-exec" || a === "-execdir" || a === "-ok" || a === "-okdir");
    if (at !== -1) {
      const end = args.findIndex((a, k) => k > at && (a === ";" || a === "\\;" || a === "+"));
      const rest = args.slice(at + 1, end === -1 ? undefined : end);
      return rest.length > 0 ? rejoin(rest) : null;
    }
  }
  return null;
}

const SQL_DESTRUCTIVE = /\b(drop\s+(table|schema|database|view|materialized\s+view|function|index|policy|role|extension|type|trigger|sequence|owned|publication)|truncate\b|delete\s+from\b|alter\s+table\s+\S+\s+drop\b|update\s+\S+\s+set\b(?![\s\S]*\bwhere\b))/i;
const SQL_CLIENTS = new Set(["psql", "pgcli", "mysql", "sqlite3"]);
// Commands that only read or print text, so "psql" in their words isn't a client: cat log | grep psql.
const TEXT_TOOLS = new Set(["grep", "rg", "egrep", "fgrep", "echo", "printf", "cat", "less", "more", "head", "tail", "tee", "wc", "sed", "awk", "sort", "uniq", "cut", "tr", "jq"]);

/** A risk from our stack's own commands, or null. `what` is the pane's summary. */
function classifyStack(cmd, args, words) {
  const base = cmd.split("/").pop();
  // ASAI: supabase's global options can come before the subcommand: supabase --experimental storage rm.
  if (base === "supabase") {
    args = args.slice(skipOptions(args, SUPABASE_VALUE_OPTIONS));
  }
  const joined = words.join(" ");
  if (base === "find" && args.includes("-delete")) {
    return { kind: "find-delete", label: "find -delete", args };
  }
  if (SQL_CLIENTS.has(base)) {
    if (SQL_DESTRUCTIVE.test(joined)) {
      return { kind: "stack", label: `${base} ${joined.match(SQL_DESTRUCTIVE)[0].toLowerCase()}`, what: "run SQL that drops or deletes data" };
    }
    // SQL from a file, a redirect or a heredoc isn't on this line, so it can't be read.
    if (args.some((a) => a === "-f" || a.startsWith("--file") || /^-f\S/.test(a) || a.startsWith("<"))) {
      return { kind: "stack", label: `${base} (SQL from a file or stdin)`, what: "run SQL from a file, a redirect or a heredoc, which Blast Radius can't read" };
    }
  }
  if (base === "supabase" && args.includes("--dry-run")) {
    return null;
  }
  if (base === "supabase" && (args[0] === "functions" || args[0] === "projects" || args[0] === "branches") && args[1] === "delete") {
    return { kind: "stack", label: `supabase ${args[0]} delete`, what: `delete a Supabase ${{ functions: "edge function", projects: "project", branches: "branch database" }[args[0]]}${args[2] ? `: ${args[2]}` : ""}` };
  }
  if (base === "supabase" && args[0] === "storage" && args[1] === "rm") {
    return { kind: "stack", label: "supabase storage rm", what: "delete files from Supabase Storage" };
  }
  if (base === "supabase" && args[0] === "migration" && args[1] === "repair") {
    return { kind: "stack", label: "supabase migration repair", what: "rewrite the remote migration history" };
  }
  if ((base === "prisma" && args[0] === "db" && args[1] === "push") || (base === "prisma" && args[0] === "migrate" && args[1] === "reset")) {
    return { kind: "stack", label: `prisma ${args[0]} ${args[1]}`, what: args[1] === "push" ? "change the database schema directly, without a migration file" : "wipe the database and rerun every migration" };
  }
  // npm run db:push, pnpm db:reset, yarn db:drop, bun run db:push
  if (base === "npm" || base === "pnpm" || base === "yarn" || base === "bun") {
    const script = args[0] === "run" || args[0] === "run-script" ? args[1] : args[0];
    if (script !== undefined && DB_SCRIPT.test(script)) {
      return { kind: "stack", label: `${base} ${script}`, what: `run the package script ${script}, which by its name changes a database` };
    }
  }
  if (base === "supabase" && args[0] === "db" && (args[1] === "reset" || args[1] === "push")) {
    const linked = args.includes("--linked") || args.includes("--db-url");
    return {
      kind: "stack",
      label: `supabase db ${args[1]}`,
      what: args[1] === "reset"
        ? `wipe and rebuild the ${linked ? "LINKED (remote) " : "local "}database`
        : "apply local migrations to the linked (remote) database",
    };
  }
  if (base === "vercel" || base === "vc") {
    // Global options can come first, and some take a value: vercel --scope my-team env rm X.
    const sub = [];
    for (let i = 0; i < args.length; i += 1) {
      if (VERCEL_VALUE_OPTIONS.has(args[i])) {
        i += 1;
      } else if (!args[i].startsWith("-")) {
        sub.push(args[i]);
      }
    }
    if ((sub[0] === "env" && (sub[1] === "rm" || sub[1] === "remove")) || ((sub[0] === "domains" || sub[0] === "dns" || sub[0] === "projects" || sub[0] === "project" || sub[0] === "alias" || sub[0] === "aliases") && (sub[1] === "rm" || sub[1] === "remove"))) {
      return { kind: "stack", label: `vercel ${sub[0]} ${sub[1]}`, what: `remove ${sub[0] === "env" ? "an environment variable" : sub[0]} from Vercel${sub[2] ? `: ${sub[2]}` : ""}` };
    }
    if (sub[0] === "rm" || sub[0] === "remove") {
      return { kind: "stack", label: "vercel rm", what: `remove Vercel deployments or a project${sub[1] ? `: ${sub[1]}` : ""}` };
    }
  }
  if (base === "drizzle-kit" && (args.includes("push") || args.includes("drop"))) {
    const sub = args.includes("push") ? "push" : "drop";
    return { kind: "stack", label: `drizzle-kit ${sub}`, what: sub === "push" ? "change the database schema directly, without a migration file" : "delete a migration" };
  }
  if (base === "gh" && (args[0] === "repo" || args[0] === "release") && args[1] === "delete") {
    return { kind: "stack", label: `gh ${args[0]} delete`, what: `delete a GitHub ${args[0]}${args[2] ? `: ${args[2]}` : ""}` };
  }
  if (base === "gh" && args[0] === "api" && args.some((a, k) => /^(-X|--method)=?DELETE$/i.test(a) || ((a === "-X" || a === "--method") && /^delete$/i.test(args[k + 1] ?? "")))) {
    return { kind: "stack", label: "gh api DELETE", what: "send a DELETE to the GitHub API" };
  }
  if (base === "gh" && args[0] === "pr" && args[1] === "close" && args.includes("--delete-branch")) {
    return { kind: "stack", label: "gh pr close --delete-branch", what: "close a pull request and delete its branch" };
  }
  if (cmd === "git") {
    let i = 0;
    while (i < args.length && args[i].startsWith("-")) {
      i += args[i] === "-C" || args[i] === "-c" ? 2 : 1;
    }
    const sub = args[i];
    const rest = args.slice(i + 1);
    const flags = rest.filter((a) => a.startsWith("-"));
    // Short flags combine: -D, -Df, -fd, -d -f.
    const short = (letter) => flags.some((f) => new RegExp(`^-[a-zA-Z]*${letter}`).test(f));
    if (sub === "worktree" && rest[0] === "remove" && (short("f") || flags.includes("--force"))) {
      return { kind: "stack", label: "git worktree remove --force", what: `remove a worktree and its uncommitted changes${rest[rest.length - 1] && !rest[rest.length - 1].startsWith("-") && rest.length > 1 ? `: ${rest[rest.length - 1]}` : ""}` };
    }
    if (sub === "branch" && (short("D") || ((short("d") || flags.includes("--delete")) && (short("f") || flags.includes("--force"))))) {
      return { kind: "stack", label: "git branch -D", what: `force-delete branch ${rest.filter((a) => !a.startsWith("-")).join(" ")}`.trim() };
    }
    if (sub === "stash" && (rest[0] === "drop" || rest[0] === "clear")) {
      return { kind: "stack", label: `git stash ${rest[0]}`, what: rest[0] === "clear" ? "delete every stash" : "delete a stash" };
    }
    if (sub === "push" && (flags.includes("--delete") || flags.includes("-d") || rest.some((a) => /^:[^:]/.test(a)))) {
      return { kind: "stack", label: "git push --delete", what: "delete a branch or tag on the remote" };
    }
  }
  return null;
}

// Resolves a `cd` target to an absolute folder, or null if it doesn't exist.
// The target is passed as an argument, never as source.
const CD_SCRIPT = `unset CDPATH; d="$1"; case "$d" in "~") d="$HOME";; "~/"*) d="$HOME/\${d#\\~/}";; esac; cd -- "$d" 2>/dev/null && pwd -P`;

async function resolveDir($, sessionCwd, dir) {
  if (dir === "-") {
    return null; // `cd -` depends on the shell's history
  }
  const run = await $.process.run(["bash", "-c", CD_SCRIPT, "blast-radius", dir], { cwd: sessionCwd, timeoutMs: 5000 });
  const out = run.stdout.trim();
  return run.exitCode === 0 && out !== "" ? out : null;
}

/** Splits one segment into words, honouring quotes. Good enough to read flags and paths. */
function tokenize(text) {
  const words = [];
  const re = /"((?:[^"\\]|\\.)*)"|'([^']*)'|(\S+)/g;
  let m;
  while ((m = re.exec(text)) !== null) {
    words.push(m[1] ?? m[2] ?? m[3]);
  }
  return words;
}

// ---- Measuring the blast radius -------------------------------------------

/** { summary, lines, note } for the pane. Never throws: a failed read is said, not hidden. */
async function measure($, risk, cwd) {
  try {
    if (risk.kind === "rm") {
      return await measureRm($, risk, cwd);
    }
    if (risk.kind === "migrate") {
      return await measureMigrations($, risk, cwd);
    }
    // ASAI: our stack's commands aren't measured; the pane says what they do.
    if (risk.kind === "stack") {
      return { summary: risk.what, lines: [], note: "Blast Radius ASAI can't measure this command. Check what it touches before you press Proceed." };
    }
    if (risk.kind === "find-delete") {
      return await measureFindDelete($, risk, cwd);
    }
    return await measureGit($, risk, cwd);
  } catch (error) {
    return { summary: `${risk.label} (could not measure it)`, lines: [], note: `Could not measure: ${String(error?.message ?? error).slice(0, 200)}` };
  }
}

// The paths are passed to bash as arguments, never as source, so nothing in
// them runs. compgen -G expands a glob without command substitution.
const RM_SCRIPT = `
shopt -s nullglob dotglob
paths=()
for p in "$@"; do
  case "$p" in "~"|"~/"*) p="$HOME\${p#\\~}";; esac
  if [[ "$p" == *[*?[]* ]]; then
    while IFS= read -r m; do paths+=("$m"); done < <(compgen -G "$p")
  elif [[ -e "$p" || -L "$p" ]]; then
    paths+=("$p")
  fi
done
if (( \${#paths[@]} == 0 )); then echo "0 0 0"; exit 0; fi
# A relative path gets ./ in front, so find never reads a name like -delete as an action.
for i in "\${!paths[@]}"; do case "\${paths[$i]}" in /*) ;; *) paths[$i]="./\${paths[$i]}";; esac; done
files=$(find "\${paths[@]}" \\( -type f -o -type l \\) 2>/dev/null | wc -l | tr -d ' ')
kb=$(du -skc "\${paths[@]}" 2>/dev/null | tail -n1 | cut -f1)
echo "$files $(( \${kb:-0} * 1024 )) \${#paths[@]}"
find "\${paths[@]}" \\( -type f -o -type l \\) 2>/dev/null | head -n ${LIST_MAX}
`;

async function measureRm($, risk, cwd) {
  if (risk.targets.length === 0) {
    return { summary: "rm with no paths", lines: [], note: "No paths to expand." };
  }
  const run = await $.process.run(["bash", "-c", RM_SCRIPT, "blast-radius", ...risk.targets], { cwd, timeoutMs: 15000 });
  const [head, ...rest] = run.stdout.split("\n").filter((l) => l !== "");
  const [files, bytes, found] = (head ?? "0 0 0").split(" ").map(Number);
  if (!found) {
    return { summary: `delete nothing: no file matches ${risk.targets.join(" ")}`, lines: [], note: "The paths don't exist, so rm has nothing to remove." };
  }
  if (!files) {
    return { summary: `delete ${found} ${found === 1 ? "path" : "paths"} with no files in ${found === 1 ? "it" : "them"}`, lines: [], note: `Paths: ${risk.targets.join(" ")}` };
  }
  return {
    summary: `delete ${files} ${files === 1 ? "file" : "files"} (about ${size(bytes)})`,
    lines: rest.map((l) => l.replace(/^\.\//, "")),
    more: Math.max(0, files - rest.length),
    note: `Paths: ${risk.targets.join(" ")}`,
  };
}

// ASAI: the same find without -delete lists what it would delete. Actions that
// do something else (-exec, -fprint, ...) are never run here; then it isn't measured.
const FIND_ACTIONS = /^-(exec|execdir|ok|okdir|fprint|fprint0|fprintf|fls)$/;

async function measureFindDelete($, risk, cwd) {
  if (risk.args.some((a) => FIND_ACTIONS.test(a))) {
    return { summary: "find -delete (not measured)", lines: [], note: "This find also runs other actions, so it wasn't dry-run." };
  }
  const run = await $.process.run(["find", ...risk.args.filter((a) => a !== "-delete")], { cwd, timeoutMs: 15000 });
  if (run.exitCode !== 0) {
    return { summary: "find -delete (could not dry-run it)", lines: [], note: run.stderr.trim().slice(0, 200) || "find without -delete failed." };
  }
  const gone = run.stdout.split("\n").filter((l) => l !== "");
  return {
    summary: gone.length === 0 ? "delete nothing: find matches no files" : `delete ${gone.length} ${gone.length === 1 ? "path" : "paths"}`,
    lines: gone.slice(0, LIST_MAX).map((l) => l.replace(/^\.\//, "")),
    more: Math.max(0, gone.length - LIST_MAX),
    note: "From the same find without -delete.",
  };
}

async function measureGit($, risk, cwd) {
  if (risk.kind === "git-push-force") {
    return await measurePush($, risk, cwd);
  }
  if (risk.kind === "git-clean") {
    const flags = [];
    const paths = [];
    for (let i = 0; i < risk.args.length; i += 1) {
      const a = risk.args[i];
      if (a === "--") {
        paths.push(...risk.args.slice(i + 1));
        break;
      }
      if (a === "-e" || a === "--exclude") {
        flags.push(a, risk.args[i + 1] ?? "");
        i += 1;
      } else if (a.startsWith("--exclude=") || /^-e./.test(a)) {
        flags.push(a);
      } else if (/^-[a-zA-Z]+$/.test(a)) {
        const kept = a.replace(/[finq]/g, ""); // -n is added below; -f, -i and -q would change the dry run
        if (kept !== "-") {
          flags.push(kept);
        }
      } else if (!a.startsWith("-")) {
        paths.push(a);
      }
    }
    const run = await $.process.run(["git", "clean", "-n", ...flags, "--", ...paths], { cwd, timeoutMs: 15000 });
    if (run.exitCode !== 0) {
      return { summary: "git clean (could not dry-run it)", lines: [], note: run.stderr.trim().slice(0, 200) };
    }
    const gone = run.stdout.split("\n").filter((l) => l.startsWith("Would remove ")).map((l) => l.slice(13));
    return {
      summary: gone.length === 0 ? "remove nothing: no untracked files match" : `remove ${gone.length} untracked ${gone.length === 1 ? "path" : "paths"}`,
      lines: gone.slice(0, LIST_MAX),
      more: Math.max(0, gone.length - LIST_MAX),
      note: "From git clean -n. Untracked files are not in git, so they can't be recovered.",
    };
  }
  const status = await $.process.run(["git", "status", "--porcelain"], { cwd, timeoutMs: 15000 });
  if (status.exitCode !== 0) {
    return { summary: `${risk.label} (not a git repo here?)`, lines: [], note: status.stderr.trim().slice(0, 200) };
  }
  const rows = status.stdout.split("\n").filter((l) => l.length > 3 && !l.startsWith("??"));
  // reset --hard drops staged and unstaged changes; checkout -- . drops unstaged ones.
  const lost = risk.kind === "git-reset" ? rows : rows.filter((l) => l[1] !== " ");
  const stat = await $.process.run(["git", "diff", "--shortstat", risk.kind === "git-reset" ? "HEAD" : "--"], { cwd, timeoutMs: 15000 });
  return {
    summary: lost.length === 0 ? "discard nothing: no uncommitted changes" : `discard uncommitted changes in ${lost.length} ${lost.length === 1 ? "file" : "files"}`,
    lines: lost.slice(0, LIST_MAX).map((l) => `${l.slice(0, 2)} ${l.slice(3)}`),
    more: Math.max(0, lost.length - LIST_MAX),
    note: stat.stdout.trim() !== "" ? `${stat.stdout.trim()}. Uncommitted changes can't be recovered.` : "From git status --porcelain.",
  };
}

async function measurePush($, risk, cwd) {
  const positional = risk.args.filter((a) => !a.startsWith("-"));
  const remote = positional[0] ?? "origin";
  // A refspec is src:dst. With no colon, the local branch of the same name is pushed.
  const spec = (positional[1] ?? "").replace(/^\+/, "");
  let [source, branch] = spec.includes(":") ? spec.split(":") : [spec, spec];
  branch = (branch ?? "").replace(/^refs\/heads\//, "");
  if (!branch) {
    const head = await $.process.run(["git", "rev-parse", "--abbrev-ref", "HEAD"], { cwd, timeoutMs: 10000 });
    branch = head.stdout.trim();
    source = "HEAD";
  } else if (branch === "HEAD") {
    // `git push origin HEAD` pushes the current branch to its namesake.
    const head = await $.process.run(["git", "rev-parse", "--abbrev-ref", "HEAD"], { cwd, timeoutMs: 10000 });
    branch = head.stdout.trim();
    source = "HEAD";
  }
  source = source || "HEAD";
  const ref = `${remote}/${branch}`;
  const known = await $.process.run(["git", "rev-parse", "--verify", "--quiet", ref], { cwd, timeoutMs: 10000 });
  if (known.exitCode !== 0) {
    return { summary: `force-push to ${ref}`, lines: [], note: `No local copy of ${ref}, so I can't tell which commits the push would drop. Run git fetch first.` };
  }
  const log = await $.process.run(["git", "log", "--oneline", "--no-decorate", `${source}..${ref}`], { cwd, timeoutMs: 15000 });
  const dropped = log.stdout.split("\n").filter((l) => l !== "");
  return {
    summary: dropped.length === 0 ? `force-push to ${ref}: drops no commits` : `force-push to ${ref}: drops ${dropped.length} ${dropped.length === 1 ? "commit" : "commits"}`,
    lines: dropped.slice(0, LIST_MAX),
    more: Math.max(0, dropped.length - LIST_MAX),
    note: `Commits on ${ref} that ${source} doesn't have, as of the last fetch.`,
  };
}

const MIGRATION_LISTERS = {
  django: { argv: ["python3", "manage.py", "showmigrations", "--plan"], pending: (l) => l.startsWith("[ ]"), strip: (l) => l.slice(4) },
  alembic: { argv: ["alembic", "history", "-r", "current:head"], pending: (l) => l.includes("->"), strip: (l) => l },
  rails: { argv: ["bin/rails", "db:migrate:status"], pending: (l) => /^\s*down\b/.test(l), strip: (l) => l.trim() },
  prisma: { argv: ["npx", "--no-install", "prisma", "migrate", "status"], pending: (l) => /^\s{2}\S/.test(l), strip: (l) => l.trim() },
};

async function measureMigrations($, risk, cwd) {
  const lister = MIGRATION_LISTERS[risk.tool];
  if (lister === undefined) {
    return { summary: "run migrations", lines: [], note: "I can't list the pending migrations for this tool, so the list is not shown." };
  }
  let run;
  try {
    run = await $.process.run(lister.argv, { cwd, timeoutMs: 20000 });
  } catch (error) {
    run = { exitCode: -1, stdout: "", stderr: String(error?.message ?? error) };
  }
  if (run.exitCode !== 0) {
    return { summary: `run ${risk.label}`, lines: [], note: `Couldn't list pending migrations (${lister.argv.join(" ")} failed).` };
  }
  const pending = run.stdout.split("\n").filter(lister.pending).map(lister.strip);
  return {
    summary: pending.length === 0 ? `run ${risk.label}: nothing pending` : `apply ${pending.length} pending ${pending.length === 1 ? "migration" : "migrations"}`,
    lines: pending.slice(0, LIST_MAX),
    more: Math.max(0, pending.length - LIST_MAX),
    note: `From ${lister.argv.join(" ")}.`,
  };
}

function size(bytes) {
  if (!Number.isFinite(bytes) || bytes < 1024) {
    return `${bytes || 0} B`;
  }
  const units = ["KB", "MB", "GB", "TB"];
  let n = bytes;
  let i = -1;
  while (n >= 1024 && i < units.length - 1) {
    n /= 1024;
    i += 1;
  }
  return `${n.toFixed(n < 10 ? 1 : 0)} ${units[i]}`;
}

// ---- Drawing --------------------------------------------------------------

function paneRows(report) {
  return Math.min(24, 9 + report.lines.length + (report.more ? 1 : 0));
}

function draw(t, state) {
  const { Box, Text, Button } = t;
  const { report } = state;
  const list = report.lines.map((line, i) => Text({ key: `l${i}`, children: `  ${line}`, wrap: "truncate-end" }));
  if (report.more) {
    list.push(Text({ key: "more", dimColor: true, children: `  + ${report.more} more` }));
  }
  // The buttons answer the call this pane was drawn for, never whichever one is held now.
  const decide = (choice) => () => {
    if (state.decision === null) {
      state.decision = choice;
    }
  };
  return Box({
    flexDirection: "column",
    borderStyle: "round",
    borderColor: "yellow",
    paddingX: 1,
    children: [
      Text({ key: "title", bold: true, color: "yellow", children: `⚠ Blast Radius · ${state.risk.label}` }),
      Text({ key: "cmd", children: [Text({ dimColor: true, children: "Command  " }), Text({ bold: true, children: state.command })], wrap: "truncate-end" }),
      Text({ key: "sum", children: [Text({ dimColor: true, children: "Would    " }), Text({ color: "red", bold: true, children: report.summary })] }),
      Box({ key: "list", flexDirection: "column", marginTop: 1, children: list }),
      report.note ? Text({ key: "note", dimColor: true, italic: true, children: report.note, wrap: "wrap" }) : null,
      Box({
        key: "buttons",
        marginTop: 1,
        gap: 2,
        children: [
          Button({ key: "proceed", label: "Proceed", hotkey: "1", plain: true, onPress: decide("proceed") }),
          Button({ key: "cancel", label: "Cancel", hotkey: "2", plain: true, autoFocus: true, onPress: decide("cancel") }),
          Text({ key: "hint", dimColor: true, children: "Claude is waiting on your answer" }),
        ],
      }),
    ],
  });
}
