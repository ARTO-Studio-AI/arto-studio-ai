# blast-radius-asai · cambios de ARTO Studio AI sobre Blast Radius

Base: `blast-radius` 0.1.0 de Anthropic (Claude Code DevRel), repositorio `anthropics/claude-code-playground`, commit `569c5283d9a0a7ee7938df85bb32e4f48cbb8c86`, licencia Apache-2.0 (texto completo en `LICENSE`). Cambios de ARTO Studio AI (ASAI), octubre de 2026. Cada cambio en el código está marcado con `ASAI:`. El `README.md` es el del autor y describe el mod original; este archivo dice qué cambia.

## Qué cambia
1. **Comandos envueltos.** Revisa lo que va dentro de `bash -c`, `sh -c`, `zsh -c`, `eval`, `timeout`, `doas`, `env -i`, `time -p`, `npx`, `bunx`, `pnpm dlx`, `yarn dlx`, `$(...)` y comillas invertidas. Con `xargs` y `find -exec` dice qué se ejecutaría (las rutas llegan al correr, así que no las cuenta). Abre hasta 4 niveles; más allá lo detiene como ilegible.
2. **Otra máquina u otro contenedor.** Revisa lo que corre dentro de `docker exec`, `docker compose exec`, `docker-compose exec` y `ssh host`, también con opciones antes de `exec`. Como corre en otro lado, no lo mide: dice qué haría.
3. **Bases de datos y despliegue.** Detiene el reset y el push de base de datos de Supabase, `supabase migration repair`, `storage rm` y `branches delete`; `psql`, `mysql`, `sqlite3` y `pgcli` con `drop`, `truncate`, `delete from`, `alter table … drop` o `update … set` sin `where`; `vercel rm`, `env rm`, `domains rm`, `projects rm` y `alias rm`; `drizzle-kit push` y `drop`; `prisma db push` y `migrate reset`; scripts `db:push`, `db:reset` y `db:drop`; `gh repo delete`, `gh release delete` y `gh api` con `DELETE`; `git branch -D`, `git stash drop` y `clear`, `git push --delete`; `find -delete`.
4. **SQL que no se puede leer.** `psql` o `mysql` con `-f`, `--file=`, `< archivo`, heredoc o SQL que llega por un pipe se detienen, porque no se puede ver qué hacen. La línea se parte respetando comillas, así que `cat log | grep psql` o un mensaje de commit que diga `| psql` pasan.
5. **Nadie puede contestar.** En una tarea programada, una rutina, `/loop` o una sesión sin pantalla (`claude -p`), rechaza el comando al instante y le pide a Claude que te avise, en vez de esperar 10 minutos.
6. **Apagado.** `BLAST_RADIUS_ASAI=off` en el entorno lo desactiva.

## Lo que no hace
- Solo vigila la herramienta Bash de Claude Code. Lo que corre por otras herramientas (servidores MCP que ejecutan procesos, una terminal integrada, computer-use) no pasa por aquí. Para bloquear esas vías, usa reglas `deny` en los permisos de Claude Code.
- Es una red, no un candado. No lee el contenido de scripts ni de archivos `.sql`, ni ve lo que un programa de Python o Node borra por dentro.
- **Límites conocidos:** scripts por stdin (`… | bash`, `curl … | sh`); sustitución de procesos (`tee >(psql …)`); redirección pegada (`psql<fix.sql`); prefijos como `stdbuf` o `ionice`; comillas o escapes dentro de una palabra (`r\m`, `"r"m`, `$'…'`); variables (`$P`); `xargs -a archivo`; `awk` con `system()`; `ssh host -- cmd`; `docker run … rm -rf`.
- **Falsos positivos conocidos:** `psql -f consulta.sql` o `echo "select …" | psql` se detienen aunque solo lean; un heredoc o comentario cuyo texto menciona un comando peligroso también se detiene (nos pasó al escribir este mismo archivo); `ps aux | pgrep psql`.

## Cómo se comprobó
- 145 casos en `classify.test.mjs`: `BR_MODULE=hooks/blast-radius.mjs node --test classify.test.mjs`.
- Cuatro auditorías independientes del código, la última sin hallazgos bloqueantes.
- `claude plugin validate` con Claude Code 2.1.308: Validation passed.
- Prueba en vivo en Mac con Claude Code 2.1.308 y permisos en bypass: detuvo `bash -c 'rm -rf build'`, `git reset --hard`, SQL por pipe y `docker compose … psql` (Cancelar los dejó intactos), dejó pasar `cat … | grep` y borró la carpeta solo cuando se pulsó Proceder.
- En uso real dentro de ARTO Studio AI: detuvo un comando cuyo texto mencionaba un reset de base de datos, sin dejarlo correr.
