// Pruebas del clasificador de Blast Radius ASAI. Uso: node --test classify.test.mjs <ruta a blast-radius.mjs>
import { test } from "node:test";
import assert from "node:assert/strict";
import { pathToFileURL } from "node:url";

const target = process.env.BR_MODULE;
const { classify } = await import(pathToFileURL(target).href);

const held = [
  // los cuatro del original
  ["rm -rf build", "rm"],
  ["git reset --hard", "git-reset"],
  ["git push --force origin main", "git-push-force"],
  ["git clean -fd", "git-clean"],
  // envoltorios (el hueco de la prueba en vivo)
  ["bash -c 'rm -rf build'", "rm"],
  ["bash -c 'echo hola; rm -rf build'", "rm"],
  ["sh -c \"git reset --hard\"", "git-reset"],
  ["zsh -lc 'rm -rf build'", "rm"],
  ["/bin/bash -c 'rm -rf build'", "rm"],
  ["eval rm -rf build", "rm"],
  ["timeout 5 rm -rf build", "rm"],
  ["timeout -s KILL 5 rm -rf build", "rm"],
  ["env -i rm -rf build", "rm"],
  ["time -p rm -rf build", "rm"],
  ["doas rm -rf build", "rm"],
  ["ls build | xargs rm -rf", "stack"],
  ["find . -name '*.tmp' -exec rm -f {} \\;", "stack"],
  ["echo $(rm -rf build)", "rm"],
  ["echo \"$(git reset --hard)\"", "git-reset"],
  ["echo `rm -rf build`", "rm"],
  ["bash -c \"sh -c 'rm -rf build'\"", "rm"],
  // nuestro stack
  ["supabase db reset", "stack"],
  ["supabase db reset --linked", "stack"],
  ["supabase db push", "stack"],
  ["psql $DATABASE_URL -c 'drop table users'", "stack"],
  ["psql -c \"TRUNCATE prompts\"", "stack"],
  ["psql -c 'delete from prompts where id=1'", "stack"],
  ["vercel env rm ADMIN_EMAILS production --yes", "stack"],
  ["vercel rm my-app --yes", "stack"],
  ["vercel domains rm example.com", "stack"],
  ["npx drizzle-kit push", "stack"],
  ["pnpm dlx drizzle-kit push", "stack"],
  ["git branch -D feature", "stack"],
  ["git branch --delete --force feature", "stack"],
  ["git stash drop", "stack"],
  ["git stash clear", "stack"],
  ["git push origin --delete feature", "stack"],
  ["git push origin :feature", "stack"],
  ["gh repo delete user/test --yes", "stack"],
  ["find . -name '*.log' -delete", "find-delete"],
  // hallazgos de la auditoría de Fable (25 oct 2026)
  ["psql \"$DATABASE_URL\" <<'SQL'\nDROP TABLE users;\nSQL", "stack"],
  ["echo \"drop table users\" | psql $DATABASE_URL", "stack"],
  ["cat fix.sql | psql $DATABASE_URL", "stack"],
  ["psql $DATABASE_URL -f scripts/drop_users.sql", "stack"],
  ["psql $DATABASE_URL < fix.sql", "stack"],
  ["echo 'DELETE FROM x' > fix.sql && psql -f fix.sql", "stack"],
  ["psql -c \"DROP TYPE status\"", "stack"],
  ["psql -c \"update prompts set tier = 'free'\"", "stack"],
  ["find . -name '*.log' -exec echo {} \\; -delete", "find-delete"],
  ["find src -name '*.bak' -delete -exec true \\;", "find-delete"],
  ["vercel --token $T rm my-app --yes", "stack"],
  ["vercel --scope my-team env rm X production -y", "stack"],
  ["vercel alias rm old.example.com", "stack"],
  ["git branch -Df feature", "stack"],
  ["git branch -fd feature", "stack"],
  ["npx prisma db push --accept-data-loss", "stack"],
  ["npx prisma migrate reset --force", "stack"],
  ["pnpm drizzle-kit push", "stack"],
  ["npm run db:push", "stack"],
  ["pnpm db:reset", "stack"],
  ["gh api -X DELETE repos/user/test", "stack"],
  ["gh api --method DELETE repos/user/test/git/refs/heads/x", "stack"],
  ["gh pr close 12 --delete-branch", "stack"],
  ["supabase functions delete enviar-correo", "stack"],
  ["supabase projects delete abc123", "stack"],
  ["git worktree remove --force ../wt", "stack"],
  ["sleep 1 & rm -rf build", "rm"],
  ["npm test |& rm -rf build", "rm"],
  // reauditoría de Fable
  ["echo \"drop table users\" | sudo -u postgres psql", "stack"],
  ["echo \"drop table users\" | PGPASSWORD=x psql -h h", "stack"],
  ["echo \"drop table users\" | docker exec -i db psql -U postgres", "stack"],
  ["supabase storage rm ss:///bucket/x.png", "stack"],
  ["supabase branches delete dev", "stack"],
  ["supabase migration repair 20261025 --status reverted", "stack"],
  // tercera auditoría de Fable
  ["docker exec -i db psql -U postgres -c 'drop table x'", "stack"],
  ["docker exec db psql < fix.sql", "stack"],
  ["docker compose exec db psql -c 'drop table x'", "stack"],
  ["docker exec -it -u postgres db bash -c 'rm -rf /data'", "stack"],
  ["ssh server psql -c 'drop table x'", "stack"],
  ["ssh server 'rm -rf ~/x'", "stack"],
  ["ssh -p 22 server 'cd ~/P && git reset --hard'", "stack"],
  ["supabase --experimental storage rm ss:///b/x.png", "stack"],
  ["(echo 'drop table x' | psql)", "stack"],
  ["(echo 'drop table x' | sudo -u postgres psql)", "stack"],
  ["echo 'drop table x' | (psql)", "stack"],
  ["timeout 5 bash -c 'rm -rf build'", "rm"],
  ["npx bash -c 'rm -rf build'", "rm"],
  // cuarta auditoría de Fable
  ["docker compose -f docker-compose.yml exec db psql -c 'drop table x'", "stack"],
  ["docker compose -p asai exec db psql -c 'drop table x'", "stack"],
  ["docker --context mini exec db psql -c 'drop table x'", "stack"],
  ["docker -H ssh://mini exec db psql -c 'drop table x'", "stack"],
];

const free = [
  "ls -la",
  "git status",
  "git push origin main",
  "git branch -d feature",
  "git stash",
  "git stash pop",
  "rm notas.tmp",
  "echo 'rm -rf build'",
  "git commit -m 'arreglo; rm -rf build'",
  "git commit -m \"quita el rm -rf de build\"",
  "bash -c 'npm test'",
  "supabase db diff",
  "psql -c 'select * from prompts'",
  "vercel env ls",
  "vercel deploy --prod",
  "npx drizzle-kit generate",
  "find . -name '*.log'",
  "timeout 5 npm test",
  "grep -r 'drop table' src",
  "cat migrate.sql",
  // hallazgos de la auditoría de Fable (25 oct 2026)
  "supabase db push --dry-run",
  "supabase db reset --dry-run",
  "npm test 2>&1 | tee log.txt",
  "npm run build &> build.log",
  "false || psql -c 'select 1'",
  "psql -c \"update prompts set tier = 'pro' where id = 3\"",
  "git branch -d feature",
  "git worktree remove ../wt",
  "npm run db:generate",
  "pnpm drizzle-kit generate",
  "gh api repos/user/test",
  "gh pr close 12",
  "vercel --scope my-team env ls",
  // reauditoría de Fable
  "git commit -m \"fix pipe | psql reader\"",
  "grep -rn \"| psql\" docs/",
  "echo 'uso: cat x | psql'",
  "cat log | grep psql",
  "psql -c \"select 1\" | head",
  "supabase storage ls",
  // tercera auditoría de Fable
  "docker exec db psql -c 'select 1'",
  "docker ps",
  "docker compose up -d",
  "ssh server uptime",
  "ssh server 'ls ~/projects'",
  "supabase --experimental storage ls",
  "supabase branches list",
  "supabase migration list",
  "timeout 5 npm test",
  // cuarta auditoría de Fable
  "docker compose -f docker-compose.yml up -d",
  "docker --context mini ps",
  "docker compose -f x.yml exec db psql -c 'select 1'",
];

test("rm -rf build & : el & no entra como ruta", () => {
  const risk = classify("rm -rf build &");
  assert.deepEqual(risk.targets, ["build"]);
});

for (const [line, kind] of held) {
  test(`detiene: ${line}`, () => {
    const risk = classify(line);
    assert.notEqual(risk, null, "no lo detuvo");
    assert.equal(risk.kind, kind);
  });
}

for (const line of free) {
  test(`deja pasar: ${line}`, () => {
    assert.equal(classify(line), null);
  });
}

test("cd antes de bash -c: la carpeta se arrastra", () => {
  const risk = classify("cd sub && bash -c 'rm -rf build'");
  assert.equal(risk.kind, "rm");
  assert.equal(risk.dir, "sub");
});

test("anidado sin fin: se detiene como ilegible", () => {
  // Seis eval encadenados: un shell real sí corre el rm; pasa el tope de 4 y se detiene igual.
  const risk = classify("eval eval eval eval eval eval rm -rf x");
  assert.notEqual(risk, null);
  assert.equal(risk.kind, "stack");
});
